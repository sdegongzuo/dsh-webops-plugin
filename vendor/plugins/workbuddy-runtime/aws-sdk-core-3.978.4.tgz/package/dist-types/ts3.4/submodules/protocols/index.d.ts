export { AwsSmithyRpcV2CborProtocol } from "./cbor/AwsSmithyRpcV2CborProtocol";
export { AwsJson1_0Protocol } from "./json/AwsJson1_0Protocol";
export { AwsJson1_1Protocol } from "./json/AwsJson1_1Protocol";
export { AwsJsonRpcProtocol } from "./json/AwsJsonRpcProtocol";
export { AwsRestJsonProtocol } from "./json/AwsRestJsonProtocol";
export {
  JsonCodec,
  JsonCodec2,
  JsonShapeDeserializer,
  JsonShapeDeserializer2,
  JsonShapeSerializer,
  JsonShapeSerializer2,
  loadJsonRpcErrorCode,
  loadRestJsonErrorCode,
  parseJsonBody,
  parseJsonErrorBody,
} from "@smithy/core/protocols";
export { JsonSettings } from "@smithy/core/protocols";
export { AwsEc2QueryProtocol } from "./query/AwsEc2QueryProtocol";
export { AwsQueryProtocol } from "./query/AwsQueryProtocol";
export { QuerySerializerSettings } from "./query/QuerySerializerSettings";
export { QueryShapeSerializer } from "./query/QueryShapeSerializer";
export { AwsRestXmlProtocol } from "./xml/AwsRestXmlProtocol";
export { XmlCodec } from "./xml/XmlCodec";
export { XmlSettings } from "./xml/XmlCodec";
export { XmlShapeDeserializer } from "./xml/XmlShapeDeserializer";
export { XmlShapeSerializer } from "./xml/XmlShapeSerializer";
export { parseXmlBody, parseXmlErrorBody, loadRestXmlErrorCode } from "./xml/parseXmlBody";
export { awsExpectUnion } from "./json/awsExpectUnion";
export { _toStr, _toBool, _toNum } from "./coercing-serializers";
