import {
  ServiceExceptionOptions as __ServiceExceptionOptions,
  ServiceException as __ServiceException,
} from "@smithy/core/client";
export { __ServiceExceptionOptions };
export { __ServiceException };
export declare class SSOOIDCServiceException extends __ServiceException {
  static readonly shapeId: string;
  constructor(options: __ServiceExceptionOptions);
}
