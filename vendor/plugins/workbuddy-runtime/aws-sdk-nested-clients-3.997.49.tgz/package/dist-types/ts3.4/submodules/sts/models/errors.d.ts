import { ExceptionOptionType as __ExceptionOptionType } from "@smithy/core/client";
import { STSServiceException as __BaseException } from "./STSServiceException";
export declare class ExpiredTokenException extends __BaseException {
  static readonly shapeId: string;
  readonly name: "ExpiredTokenException";
  readonly $fault: "client";
  constructor(opts: __ExceptionOptionType<ExpiredTokenException, __BaseException>);
}
export declare class MalformedPolicyDocumentException extends __BaseException {
  static readonly shapeId: string;
  readonly name: "MalformedPolicyDocumentException";
  readonly $fault: "client";
  constructor(opts: __ExceptionOptionType<MalformedPolicyDocumentException, __BaseException>);
}
export declare class PackedPolicyTooLargeException extends __BaseException {
  static readonly shapeId: string;
  readonly name: "PackedPolicyTooLargeException";
  readonly $fault: "client";
  constructor(opts: __ExceptionOptionType<PackedPolicyTooLargeException, __BaseException>);
}
export declare class RegionDisabledException extends __BaseException {
  static readonly shapeId: string;
  readonly name: "RegionDisabledException";
  readonly $fault: "client";
  constructor(opts: __ExceptionOptionType<RegionDisabledException, __BaseException>);
}
export declare class IDPRejectedClaimException extends __BaseException {
  static readonly shapeId: string;
  readonly name: "IDPRejectedClaimException";
  readonly $fault: "client";
  constructor(opts: __ExceptionOptionType<IDPRejectedClaimException, __BaseException>);
}
export declare class InvalidIdentityTokenException extends __BaseException {
  static readonly shapeId: string;
  readonly name: "InvalidIdentityTokenException";
  readonly $fault: "client";
  constructor(opts: __ExceptionOptionType<InvalidIdentityTokenException, __BaseException>);
}
export declare class IDPCommunicationErrorException extends __BaseException {
  static readonly shapeId: string;
  readonly name: "IDPCommunicationErrorException";
  readonly $fault: "client";
  $retryable: {};
  constructor(opts: __ExceptionOptionType<IDPCommunicationErrorException, __BaseException>);
}
