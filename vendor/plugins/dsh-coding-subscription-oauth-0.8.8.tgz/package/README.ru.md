

<!-- banner -->
<div align="center">

# 🔐 dsh-coding-subscription-oauth

**v0.8.2 · ранее `dsh-grok-build`

**Плагин OAuth для подписок на кодинг для [DeepSeek Harness](https://github.com/deepseek-ai/dsh).** Войдите один раз по уже оплаченным подпискам — и используйте их модели из страницы настроек или CLI dsh. **Никаких вставленных токенов в чат.**

[![License](https://img.shields.io/badge/license-Apache--2.0-green.svg)](LICENSE)
[![PRs Welcome](https://img.shields.io/badge/PRs-welcome-brightgreen.svg)](CONTRIBUTING.md)

*[English](README.md) · [中文版](README.zh-CN.md) · [日本語](README.ja.md) · [한국어](README.ko.md) · [Português (BR)](README.pt-BR.md) · [Español](README.es.md) · [Français](README.fr.md) · [Deutsch](README.de.md) · [Русский](README.ru.md)*

</div>

---

> **Обновление:** Следуйте пошаговым инструкциям по версиям в [`INSTALL.md`](INSTALL.md). `0.7.0` сохраняет общий runtime диспетчера на `dsh-coding-oauth-core@0.1.2` и `undici@7.29.0` и ограничивает reveal/rotate ключа Gateway доступом loopback; миграция конфигурации, учётных данных, данных или маршрутов не требуется. Grok Imagine сохраняет явно закреплённый dispatcher. Релизы начиная с `0.6.2` включают строгое исправление запуска Cordis-инъекции и поддержку DSH `0.1.1-rc.2`; сохраните файлы profile/config/учётных данных и перезапустите существующий процесс DSH Web только один раз после обновления. При совместном использовании Hub и Subscription `dsh-coding-oauth-core@0.1.2` с `undici@7.29.0` — их общий runtime-pin, а не отдельный плагин DSH.

---

## Смена имени

Сначала репозиторий назывался **`dsh-grok-build`** (только Grok Build). Теперь это OAuth для SuperGrok / Codex / Kimi / Claude / Antigravity.

| | Используйте | По-прежнему работает |
|---|---|---|
| GitHub / `dsh plugin add` | [`dsh-coding-subscription-oauth`](https://github.com/lninghaha/dsh-coding-subscription-oauth) | `github:lninghaha/dsh-grok-build` (тот же `main`) |
| npm | `dsh-coding-subscription-oauth@0.8.8` (текущая версия) | Старого npm-пакета не было |
| CLI | `dsh-coding-oauth` | `dsh-grok-build` |
| Cordis plugin id | `llm-grok-build-oauth` | без изменений |
| HTTP API страницы настроек | `/plugins/dsh-grok-build/*` | без изменений |
| Файлы учёток | `$DSH_HOME/.grok-build-auth.json` и остальные `*-oauth-auth.json` | без изменений |

## ✨ Возможности

- 🧾 **Своя подписка** — используйте уже оплаченные планы для кодинга вместо отдельных API-ключей.
- 🔑 **Локальный OAuth, без вставки ключа** — авторизация в странице настроек или CLI; токены никогда не попадают в чат.
- 🧩 **Один плагин, пять провайдеров** — Grok Build, Codex, Kimi, Claude и Google Antigravity.
- 🛡️ **Безопасность по замыслу** — файлы учётных данных только-владелец `0600`, атомарная запись, межпроцессная блокировка файла.
- ⚙️ **Динамический каталог** — селектор показывает только авторизованные маршруты с пометкой `(OAuth)`, включая `xhigh` для grok-4.6.
- 🌐 **С учётом прокси** — проксируется только проверенные доверенные домены подписок.
- 📥 **Ручной CLI Pull** — настройки обнаруживают разрешённые официальные OAuth-файлы CLI Grok/Codex/Kimi/Claude только для чтения; вы забираете одностороннюю копию после предпросмотра и подтверждения перезаписи.
- 🗂️ **Настройки во вкладках** — Accounts, Gateway, Capabilities и About; на удалённых хостах предпочтителен device code и меньше шума CLI missing; вошедшие карточки свёрнуты, пока их не развернёшь.
- 🎛️ **Опциональные возможности, по умолчанию выключены** — поиск Codex, использование/квота, генерация/редактирование изображений, Fast и Grok Imagine применяются сразу при включении. Дополнительный выключенный по умолчанию переключатель разрешает маршрутам не-Codex моделей вызывать инструменты изображений Codex, не обходя вход Codex, сессию и проверку владения вложениями.
- 🔌 **Локальный API-шлюз по opt-in** — по умолчанию выключенный loopback-сервер, совместимый с OpenAI/Anthropic; для ваших собственных инструментов, а не публичный relay.
- **OpenCode Go** — Подключите OpenCode Go в разделе **Учётные записи и модели**, чтобы использовать его в DSH без шлюза. Внешние инструменты используют явные маршруты `opencode-go/<model-id>`, соответствующий протокол и постоянный идентификатор беседы. Локальный ключ отделён от учётных данных провайдера. Запрос без идентификатора отклоняется; старый глобальный режим меняется после просмотра миграции.

## Какие проблемы подключения закрывает этот плагин

Обычно сюда приходят по этим поисковым запросам и ошибкам DSH.
| Искали / увидели | Что на самом деле сломано | Что делает плагин |
|---|---|---|
| SuperGrok / X Premium в DSH, Grok Build vs `api.x.ai` | Встроенный маршрут `xai` — это pay-as-you-go API. Подписка ходит на `cli-chat-proxy.grok.com` | Маршрут `grok-build` + отпечаток CLI (`X-XAI-Token-Auth` и др.), чтобы не ловить тихий 403 |
| `API key is invalid` / `AUTH` | GUI показывает этот текст на **любой** AUTH. Часто просто истёк короткий OAuth access token | Refresh за **5 минут** до expiry; при 401 токен сбрасывается и **step повторяется** |
| `INVALID_REPLAY_STATE` на втором ходе Codex/Kimi | Replay всё ещё нёс нативный provider id pi-ai | Сохраняется id маршрута Harness, старый replay чинится |
| у grok-4.6 нет **xhigh** | `/v1/models-v2` уже отдаёт `reasoning_efforts`; шаблон 4.5 прячет xhigh | Разбираем live efforts. У 4.6 есть xhigh; у 4.5 — low/medium/high |
| Kimi Code уходит как Anthropic `x-api-key` | OAuth-токен отправили как ключ Anthropic | Только `Authorization: Bearer` |
| Не вошедшие модели остаются в селекторе | Перечислялись все зарегистрированные маршруты | Неаутентифицированные маршруты пустые; вошедшие помечены `(OAuth)` |
| PKCE на удалённом / headless DSH | Нельзя вернуться на `localhost` | Device-code для Grok/Codex/Kimi; Claude принимает вставленный redirect URL |
| Прокси пускает Grok и ломает Kimi в Китае | Глобальный `HTTPS_PROXY` | Прокси только по allowlist; Kimi **напрямую**, пока не включён `proxyKimi: true` |
| OpenCode Go: `MissingSessionID` | Missing stable conversation ID | DSH: use Accounts & Models; external tools: provide `x-opencode-session`. See [migration](docs/repair-candidate.md). |

## Поддерживаемые провайдеры

| Провайдер | Маршрут | Аутентификация | Сосуществует с |
|---|---|---|---|
| **xAI Grok Build** | `grok-build` | SuperGrok / X Premium OAuth | `xai` |
| **OpenAI Codex** | `codex-oauth` | ChatGPT Plus/Pro OAuth | `openai` |
| **Kimi Code** | `kimi-code-oauth` | Kimi Code OAuth | `kimi-coding` |
| **Claude Code** | `claude-code-oauth` | Claude Pro/Max OAuth | — |
| **Google Antigravity** | `agy` | `dsh-agy` Google OAuth | — |

> Вход по устройству Grok Build, динамический каталог `/v1/models-v2` и потоковая инференция Responses проверены на реальных развёртываниях. Codex/Kimi/Claude используют нативный OAuth/refresh провайдера из `@earendil-works/pi-ai` вместо переписывания флоу каждого вендора.

## 🚀 Быстрый старт

```bash
# 1. установите текущую npm-версию в web-профиль
dsh plugin --profile web add dsh-coding-subscription-oauth@0.8.8

# 2. опционально — Google Antigravity (зафиксированная проверенная версия)
dsh plugin --profile web add dsh-agy@0.1.2

# 3. перезапустите существующий процесс DSH Web через настроенный менеджер процессов
# `dsh web` — официальный псевдоним CLI, а не имя службы.
```

Затем откройте **Settings → Coding OAuth** и войдите в любого провайдера. Готово — выберите авторизованную модель в селекторе.

## 📚 Содержание

- [Смена имени](#смена-имени)
- [Возможности](#-возможности)
- [Какие проблемы подключения закрывает этот плагин](#какие-проблемы-подключения-закрывает-этот-плагин)
- [Поддерживаемые провайдеры](#поддерживаемые-провайдеры)
- [Быстрый старт](#-быстрый-старт)
- [Установка](#установка)
- [Страница настроек](#страница-настроек)
- [Дополнительные возможности](#дополнительные-возможности)
- [Локальный API-шлюз](#локальный-api-шлюз)
- [CLI](#cli)
- [Kimi в Китае](#kimi-в-китае)
- [Сетевой прокси](#сетевой-прокси)
- [Отказоустойчивость](#отказоустойчивость)
- [Учётные данные](#учётные-данные)
- [Архитектура](#архитектура)
- [Технические заметки](#технические-заметки)
- [Соответствие](#соответствие)
- [Документация](#документация)
- [Связанное](#связанное)
- [Участие](#участие)
- [Лицензия](#лицензия)

## Установка

Установка принимает DeepSeek Harness через `engines.dsh` `>=0.1.1-rc.2 <0.3.0` (включая `0.2.1-rc.2`). Проверенный build/smoke BOM остаётся `0.1.1-rc.2`. Требуется Node.js 22.19+. Полные детали в [заметках по установке](INSTALL.md).

```bash
# текущая npm-версия (рекомендуется)
dsh plugin --profile web add dsh-coding-subscription-oauth@0.8.8

# разработка/альтернатива: из GitHub
dsh plugin --profile web add github:lninghaha/dsh-coding-subscription-oauth

# разработка/альтернатива: локальный checkout
# dsh plugin --profile web add ./dsh-coding-subscription-oauth
```

После установки перезапустите существующий процесс DSH Web. Проверка на реальном развёртывании:

```bash
pnpm run verify:deployed            # проверяет реальный /api/llm.models + статус OAuth
DSH_EXPECT_AGY_AUTH=signed-in pnpm run verify:deployed   # если Google уже вошёл

DSH_RESTORE_PROVIDER=openai \
DSH_RESTORE_MODEL=gpt-5.6-sol \
DSH_RESTORE_REASONING=max \
pnpm run smoke:deployed             # реальные вызовы Codex/Kimi + replay второго turn
```

> `smoke:deployed` создаёт временную сессию, проверяет вызовы инструментов Codex и Kimi и второй пользовательский turn (регрессию `INVALID_REPLAY_STATE`), восстанавливает объявленную модель по умолчанию и затем архивирует сессию.

## Страница настроек

Откройте **Settings → Coding OAuth**:



<table>
  <tr>
    <td align="center" valign="top" width="33%">
      <a href="media/en/settings_accounts.png"><img src="media/en/settings_accounts.png" alt="Coding OAuth Accounts tab" width="280" /></a><br />
      <sub>Accounts</sub>
    </td>
    <td align="center" valign="top" width="33%">
      <a href="media/en/settings_gateway.png"><img src="media/en/settings_gateway.png" alt="Coding OAuth Gateway tab" width="280" /></a><br />
      <sub>Gateway</sub>
    </td>
    <td align="center" valign="top" width="33%">
      <a href="media/en/settings_capabilities.png"><img src="media/en/settings_capabilities.png" alt="Coding OAuth Capabilities tab" width="280" /></a><br />
      <sub>Capabilities</sub>
    </td>
  </tr>
</table>

| Провайдер | Методы |
|---|---|
| Grok | код авторизации · код устройства · импорт CLI Grok · выбор моделей |
| Codex | код устройства (рекомендуется на удалённом DSH) · PKCE в браузере |
| Kimi | код устройства |
| Claude | PKCE в браузере (удалённый браузер может вставить полный URL редиректа localhost) |
| Antigravity | статус установки `dsh-agy` + локальные для профиля CLI-команды |

Страница настроек разделена на четыре верхние вкладки: **Accounts**, **Gateway**, **Capabilities** и **About**. Карточки вошедших провайдеров сворачиваются в компактное резюме и разворачиваются для редактирования моделей. Предпросмотр CLI pull занимает всю ширину, а статус Imagine показан на вкладке Capabilities.

Селектор показывает только маршруты, завершившие аутентификацию; неавторизованные провайдеры возвращают пустой список. Имена провайдеров получают `(OAuth)`, а каталог обновляется через `llm/adapters-updated` после входа/выхода.

## Дополнительные возможности

Все восемь переключателей `codexSearch`, `codexImages`, `codexImageEdits`, `codexImagesAnyModel`, `codexUsage`, `codexFast`, `grokImagineImage` и `grokImagineVideo` по умолчанию выключены и применяются без перезапуска. `codexImagesAnyModel` лишь ослабляет ограничение маршрута вызывающей модели; по-прежнему нужны вход в Codex, `codexImages` (и флаг edits для редактирования), а также сохраняются владение вложениями сессии и авторизация редактирования. Ограничения: `searchResults` (1–20, по умолчанию 5), `imageCount` (1–4, по умолчанию 1) и `videoArtifactTtlMs` (1 час–7 дней, по умолчанию 7 дней; в интерфейсе 1–168 часов). Уменьшение срока сразу сокращает и очищает существующие артефакты; увеличение действует только на новые.

## Локальный API-шлюз

По умолчанию **выключен**. При включении запускается изолированный `node:http`-сервер (не веб-порт DSH) на `127.0.0.1:18080`, переиспользующий те же вошедшие OAuth-сессии:

```yaml
gateway:
  enabled: false
  bind: 127.0.0.1
  port: 18080
  opencodeGo:
    enabled: false
```

Эндпоинты: `GET /healthz`, `GET /v1/models`, `POST /v1/chat/completions`, `POST /v1/responses`, `POST /v1/messages`. Bearer-ключ хранится в `$DSH_HOME/.coding-oauth-gateway.json` (`0600`). В настройках можно скопировать базовый URL OpenAI (база + `/v1`), базовый URL Anthropic и текущий Bearer-ключ без ротации; показ ключа возможен только через loopback и не сохраняется в хранилище браузера. Ротация — подтверждаемое деструктивное действие. Порт прослушивания можно отредактировать напрямую и сохранить через Apply или заполнить кнопкой Random (18100–18999); выбранный порт сохраняется в доступном только владельцу документе шлюза, а работающий listener перепривязывается. Bind по-прежнему задаётся только в YAML; для не-loopback bind требуется ключ. Это не удалённый relay.

Подключите OpenCode Go в разделе **Учётные записи и модели**, чтобы использовать его в DSH без шлюза. Внешние инструменты используют явные маршруты `opencode-go/<model-id>`, соответствующий протокол и постоянный идентификатор беседы. Локальный ключ отделён от учётных данных провайдера. Запрос без идентификатора отклоняется; старый глобальный режим меняется после просмотра миграции. [Migration / 迁移](docs/repair-candidate.md).

## CLI

```bash
# `dsh-grok-build` по-прежнему алиас той же команды
dsh-coding-oauth login [--pkce] | import | status | logout

# более новые провайдеры
dsh-coding-oauth login codex --device-auth | codex --browser | kimi | claude
dsh-coding-oauth status all
dsh-coding-oauth logout codex

# Antigravity (сначала установите в web-профиль)
dsh plugin --profile web exec dsh-agy login --headless
```

> CLI `dsh-agy` изменяет пул аккаунтов вне процесса DSH, поэтому не может отправить событие каталога внутри процесса — после входа/выхода закройте и снова откройте селектор моделей.

## Kimi в Китае

OAuth подписки Kimi Code использует `https://auth.kimi.com`; инференция — `https://api.kimi.com/coding`. `https://api.moonshot.cn/v1` — это канал API-ключей с оплатой за использование **Moonshot Open Platform**; переключаемого «китайского OAuth-эндпоинта» не существует. Этот плагин использует отдельный маршрут `kimi-code-oauth` и не влияет на существующую конфигурацию `kimi-coding` по API-ключу.

## Сетевой прокси

Приоритет: `config.proxy` → `CODING_OAUTH_PROXY` → `GROK_BUILD_PROXY` → `HTTPS_PROXY`/`HTTP_PROXY`.

```yaml
- id: llm-grok-build-oauth
  config:
    proxy: http://127.0.0.1:7890
    proxyKimi: false
```

Проксируются только проверенные домены подписок (xAI/Grok, OpenAI Codex, Claude/Anthropic, Google Antigravity); остальной трафик DSH сохраняет исходный диспетчер. Kimi по умолчанию работает напрямую и использует прокси только при `proxyKimi: true`.

## Отказоустойчивость

OAuth access token обновляется **за пять минут** до сохранённого срока (pi-ai 0.84+). Если апстрим всё же отклоняет локально ещё живой токен кодом 401/403, плагин сдвигает сохранённый `expires` в прошлое, и повторный шаг сначала обновляет токен, затем повторяет запрос.

Повторы идут по политике harness: временные сбои (`RATE_LIMIT`/`SERVER`/`TIMEOUT`/`TRANSPORT`/`EMPTY_RESPONSE`) **и `AUTH`** повторяются с экспоненциальной задержкой (5 попыток, 5 с → 10 с → 20 с → 40 с → 80 с (~155 с суммарно), 10% jitter). Исчерпание квоты и мёртвый refresh token **не** повторяются. Переопределение для развёртывания:

```yaml
- id: llm-grok-build-oauth
  config:
    retryPolicy:
      mode: normal
      maxRetries: 5
      retryableCodes: [EMPTY_RESPONSE, RATE_LIMIT, SERVER, TIMEOUT, TRANSPORT, AUTH]
      backoff: { initialDelayMs: 5000, maxDelayMs: 80000, jitterRatio: 0.1 }
```

## Учётные данные

Только-владелец `0600`, атомарная запись, межпроцессная блокировка файла:

- `$DSH_HOME/.grok-build-auth.json`
- `$DSH_HOME/.codex-oauth-auth.json`
- `$DSH_HOME/.kimi-code-oauth-auth.json`
- `$DSH_HOME/.claude-code-oauth-auth.json`

Кеши выбора живут в соответствующих файлах `*-models.json`. **Ни один HTTP-статус, лог или интерфейс не должен возвращать токен.**

## Архитектура

```mermaid
flowchart LR
    subgraph DSH["DSH Harness"]
        UI[Настройки / Web · Coding OAuth] --> LLM[llm route]
        LLM --> ALIA[Адаптер алиасов маршрутов]
    end
    ALIA --> PI[нативный провайдер pi-ai<br/>OAuth · refresh · stream]
    PI --> GROK[Grok Build]
    PI --> COD[Codex]
    PI --> KIMI[Kimi]
    PI --> CLAU[Claude]
    AGY[плагин dsh-agy] --> GAL[Google Antigravity]
```

## Технические заметки

- **Grok Build**: собственный провайдер Responses на `cli-chat-proxy.grok.com/v1`, заголовки fingerprint CLI, динамический каталог моделей.
- **Codex/Kimi/Claude**: нативные провайдеры pi-ai отвечают за OAuth и refresh; адаптер алиасов маршрутов сопоставляет их с нативными id, при этом идентичность модели не меняется.
- Токен доступа Kimi явно преобразуется в `Authorization: Bearer` — никогда не отправляется по ошибке как `x-api-key` Anthropic.
- Google Antigravity здесь **не** реверс-инжинирится; используется выделенный плагин DSH с зафиксированной версией.

## Соответствие

Использование подписок на кодинг через сторонний harness может находиться в серой зоне условий каждого вендора и вызывать контроль квот, региона или риска аккаунта. **Используйте только свои аккаунты**; этот проект не поддерживает массовые аккаунты, перепродажу квот, удалённый relay, обход paywall или выдачу себя за клиента. Для коммерческого использования предпочитайте официальные каналы API-ключей вендоров.

## Документация

| Документ | Назначение |
|---|---|
| [`INSTALL.md`](INSTALL.md) | Детали установки и использования |
| [`CHANGELOG.md`](CHANGELOG.md) | История релизов |
| [`docs/00-project-rules.md`](docs/00-project-rules.md) | Версионирование, цикл релиза, разделение публичное/личное |
| [`docs/02-architecture.md`](docs/02-architecture.md) | Внутренняя архитектура (маршруты, поток данных, модули, API) · [中文](docs/02-architecture.zh-CN.md) |
| [`CONTRIBUTING.md`](CONTRIBUTING.md) | Руководство по участию |

## Связанное

- [`dsh-agy`](https://www.npmjs.com/package/dsh-agy) — отдельный зафиксированный плагин для Google Antigravity.

## Участие

Приветствуются любые вклады — фичи, документация, переводы, отчёты об ошибках. См. **[CONTRIBUTING](CONTRIBUTING.md)** о порядке, конвенциях коммитов и цикле релиза. Если вашего языка нет в списке, отправьте PR с переводом README, и мы добавим его в таблицу выше.

## Лицензия

[Apache-2.0](LICENSE) · см. [NOTICE](NOTICE). Части заимствованы из проекта [dsh-xai](https://github.com/MirDie/dsh-xai) (Apache-2.0).
