#!/usr/bin/env node
import type { OAuthConfig } from './oauth.js';
export declare function runRefreshDaemon(options?: {
    signal?: AbortSignal;
    once?: boolean;
    log?: (line: string) => void;
    config?: OAuthConfig;
}): Promise<void>;
export declare function main(argv?: string[]): Promise<number>;
