/**
 * Plugin-start bootstrap: search the machine for a reusable SuperGrok token,
 * fall back to the xAI device-code login on a TTY, then point dsh at Grok.
 */
import type { Context } from '@deepseek-ai/cordis';
import type { OAuthConfig, StoredTokens } from './oauth.js';
export interface BootstrapResult {
    tokens: StoredTokens | null;
    searched: boolean;
    loggedIn: boolean;
    dsh: 'service' | 'file' | 'unchanged' | 'skipped';
    reason?: string;
}
export interface BootstrapOptions {
    login?: (config: OAuthConfig) => Promise<StoredTokens>;
    applyDefault?: (ctx: Context | undefined, force: boolean) => Promise<'service' | 'file' | 'unchanged'>;
    interactive?: boolean;
    /** Force the visual guide on or off instead of following the platform. */
    visual?: boolean;
    /** Override the home directory used for the bounded local token search. */
    home?: string;
}
export declare function bootstrapXaiOAuth(config: OAuthConfig, ctx?: Context, options?: BootstrapOptions): Promise<BootstrapResult>;
