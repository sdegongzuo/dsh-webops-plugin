/**
 * Project the next xAI prompt from the last provider usage so a request that
 * no longer fits the catalog context window fails as CONTEXT_WINDOW_EXCEEDED
 * *before* the proxy returns a generic HTTP 400. Harness overflow compaction
 * only retries that code.
 */
import type { GenerateOptions } from '@deepseek-ai/dsh-llm';
/**
 * Cheap, stable size of one chat-completions request. Used only as a ratio
 * against the previous request so provider-reported prompt tokens can be
 * scaled after history grows or compaction shrinks it.
 */
export declare function estimateRequestTokens(options: Pick<GenerateOptions, 'system' | 'messages' | 'tools'>): number;
/** Prompt-side tokens from a provider usage sample (cached + uncached + writes). */
export declare function promptTokensFromUsage(usage: {
    inputTokens: number;
    cacheReadTokens?: number;
    cacheWriteTokens?: number;
}): number;
/**
 * Scale the last provider-reported prompt by how the serialized request grew
 * or shrank. Compaction drops the heuristic, so the projection falls with it.
 */
export declare function projectPromptTokens(lastPromptTokens: number, lastEstimate: number, currentEstimate: number): number;
export type GeneratePurpose = 'compaction' | 'session-title';
/** True when the projected prompt no longer fits the catalog context window. */
export declare function shouldTriggerCompaction(promptTokens: number, contextWindow: number, minRemaining?: number, requestedMax?: number): boolean;
export interface RequestBudgetPlan {
    overflow: boolean;
    /** When set, serialize this completion cap instead of the caller value. */
    maxTokens?: number;
}
/**
 * Decide whether the next xAI call should fail into harness overflow
 * compaction, clamp `max_tokens`, or pass through unchanged.
 *
 * Compaction / session-title calls never trip overflow: they are how the
 * harness recovers, and they still clamp so the summarizer fits.
 */
export declare function planRequestBudget(input: {
    promptTokens: number | undefined;
    contextWindow: number;
    requestedMax: number;
    minRemaining: number;
    purpose?: GeneratePurpose;
}): RequestBudgetPlan;
export interface LastPromptBudget {
    promptTokens: number;
    estimate: number;
}
/**
 * Project the current request's prompt from the last successful sample.
 * `undefined` when this session has not yet reported usage.
 */
export declare function projectedPromptTokens(last: LastPromptBudget | undefined, currentEstimate: number): number | undefined;
