import type { FinishReason, StreamChunk, TokenUsage } from '@deepseek-ai/dsh-llm';
import type { WireUsage } from './types.js';
export declare function mapFinishReason(reason: string): FinishReason;
export declare function mapUsage(usage: WireUsage): TokenUsage;
export declare function translate(payloads: AsyncIterable<string>): AsyncGenerator<StreamChunk>;
