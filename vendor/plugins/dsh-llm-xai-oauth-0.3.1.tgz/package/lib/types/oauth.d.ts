import { ProxyAgent } from 'undici';
import type { OAuthConfig, StoredTokens } from './tokens.js';
export type { OAuthConfig, StoredTokens } from './tokens.js';
export { normalizeTokens } from './tokens.js';
export declare const DEFAULT_CLIENT_ID = "b1a00492-073a-47ea-816f-4c329264a828";
export declare const DEFAULT_SCOPE = "openid profile email offline_access grok-cli:access api:access";
export declare const DEFAULT_AUTH_BASE = "https://auth.x.ai";
export declare const DEFAULT_TOKEN_PATH = "/oauth2/token";
export declare const DEFAULT_DEVICE_CODE_PATH = "/oauth2/device/code";
export declare const DEFAULT_UPSTREAM_BASE = "https://cli-chat-proxy.grok.com/v1";
export declare const DEFAULT_API_BASE = "https://api.x.ai/v1";
export declare const DEFAULT_CLIENT_VERSION = "1.0.0";
export declare const DEFAULT_CLIENT_MODE = "cli";
export declare const REFRESH_SKEW_MS: number;
/** How often the independent refresher re-reads the token file. */
export declare const REFRESH_DAEMON_POLL_MS: number;
export interface AccessToken {
    accessToken: string;
    mode: 'oauth';
}
export declare function defaultOAuthConfig(): OAuthConfig;
export declare function loadCanonicalTokens(config: OAuthConfig): Promise<StoredTokens | null>;
export declare function adoptTokens(config: OAuthConfig, tokens: StoredTokens): Promise<StoredTokens>;
export declare function loadStoredTokens(config: OAuthConfig): Promise<StoredTokens | null>;
export declare function saveTokens(config: OAuthConfig, tokenResponse: {
    access_token: string;
    refresh_token?: string;
    expires_in?: number;
}, previousRefreshToken?: string | null): Promise<StoredTokens>;
export declare function proxyDispatcher(): ProxyAgent | undefined;
export declare function refreshTokens(config: OAuthConfig, refreshToken: string, clientId?: string | null, signal?: AbortSignal): Promise<StoredTokens>;
export declare function missingTokenError(): Error;
export declare function tokenNeedsRefresh(tokens: StoredTokens, now?: number, skewMs?: number): boolean;
export declare function refreshStoredTokens(config: OAuthConfig, options?: {
    force?: boolean;
    signal?: AbortSignal;
}): Promise<StoredTokens>;
export declare function getAccessToken(config: OAuthConfig, signal?: AbortSignal): Promise<string>;
/** Force a refresh after the upstream rejected the current access token. */
export declare function refreshAccessTokenAfterUnauthorized(config: OAuthConfig, signal?: AbortSignal): Promise<string>;
export interface DeviceCode {
    deviceCode: string;
    userCode: string;
    verificationUri: string;
    intervalSeconds: number;
    expiresInSeconds: number;
}
export declare function startDeviceAuth(config: OAuthConfig, signal?: AbortSignal): Promise<DeviceCode>;
export declare function pollDeviceAuth(config: OAuthConfig, device: DeviceCode, signal?: AbortSignal): Promise<StoredTokens>;
