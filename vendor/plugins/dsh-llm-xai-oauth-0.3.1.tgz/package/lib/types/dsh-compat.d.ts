/**
 * Small helpers shared by the plugin entry point.
 *
 * dsh 0.2.1 and newer expose plugin settings as the plugin's own Config: fields
 * marked `.volatile()` update the running instance without a reload, and the
 * `settings` service only projects that Config into generated forms. The
 * `settings.yaml` section API that 0.1.5 used was removed upstream, so this
 * module no longer carries a shim for it.
 */
/**
 * JSON-compatible deep equality. Mirrors the `@deepseek-ai/dsh-util-values`
 * implementation exactly so the plugin needs no extra dependency and behaves
 * identically on every supported engine.
 */
export declare function deepEqualJson(a: unknown, b: unknown): boolean;
