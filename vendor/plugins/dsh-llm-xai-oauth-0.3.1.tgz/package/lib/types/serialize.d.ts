import type { ContentBlock, GenerateOptions } from '@deepseek-ai/dsh-llm';
import type { WireMessage, WireRequest } from './types.js';
/**
 * One model-visible message, read structurally so the same build serves both
 * hosts this plugin declares:
 *
 * - dsh 0.1.5-rc carries a tool result as a `tool-result` block inside a
 *   user-role message (`toolCallId` lives on the block).
 * - dsh 0.1.7-rc.1 carries it as its own `tool`-role message (`toolCallId`
 *   lives on the message) and may also hand adapters a `developer` message.
 *
 * `GenerateOptions.messages` is also wider than durable `Message` on 0.1.7
 * (request-only user inputs have no id), so this does not import `Message`.
 */
interface RequestMessage {
    role: string;
    content: readonly ContentBlock[];
    toolCallId?: string;
    isError?: boolean;
}
export type ImageDataByAttachmentId = ReadonlyMap<string, string>;
export type XaiReasoningEffort = 'off' | 'low' | 'medium' | 'high' | 'xhigh';
export interface RequestDefaults {
    reasoningEffort?: XaiReasoningEffort;
}
export declare function reasoningEffort(effort: string): Exclude<XaiReasoningEffort, 'off'> | 'off';
/**
 * Translate harness messages onto the OpenAI-compatible wire shape.
 *
 * Both hosts this plugin runs on leave `GenerateOptions.system` undefined for
 * a loop-built request and carry the rendered prompt as a leading
 * `system`-role message. `serializeRequest` still prepends `options.system`
 * when a hand-built one-shot sets it.
 *
 * Tool results differ by host and both shapes are read here: 0.1.5 nests a
 * `tool-result` block in a user message, 0.1.7 sends a `tool`-role message.
 * Either way the wire is an OpenAI `tool` message keyed by the call id.
 *
 * `file` blocks and offloaded images are projected to text by the harness
 * before dispatch, and `developer` messages (0.1.7 tool-set changes) have no
 * producer yet. Unknown roles and block types fall through as a no-op.
 */
export declare function serializeMessages(messages: readonly RequestMessage[], images?: ImageDataByAttachmentId): WireMessage[];
export declare function serializeRequest(options: GenerateOptions, defaults?: RequestDefaults, images?: ImageDataByAttachmentId): WireRequest;
export {};
