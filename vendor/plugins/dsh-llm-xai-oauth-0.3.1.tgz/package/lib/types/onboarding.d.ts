import type { DeviceCode, OAuthConfig, StoredTokens } from './oauth.js';
export interface OnboardingOptions {
    /** Reuse an existing device grant instead of requesting a new one. */
    device?: DeviceCode;
    /** Open the guide in the default browser as soon as it is listening. */
    open?: (url: string) => boolean | Promise<boolean>;
    /** Report the guide URL on hosts that cannot open a browser. */
    announce?: (url: string) => void;
    signal?: AbortSignal;
}
export interface OnboardingHandle {
    url: string;
    /** Resolves once the browser-side grant completes and tokens are stored. */
    tokens: Promise<StoredTokens>;
    close(): Promise<void>;
}
type Status = 'waiting' | 'authorized' | 'error' | 'expired';
interface ViewState {
    status: Status;
    userCode: string;
    verificationUri: string;
    authFile: string;
    detail: string;
    expiresAt: number;
    source?: string;
}
export declare function renderOnboardingPage(state: ViewState, pathToken: string): string;
/**
 * Serve the guide, open it, and resolve once xAI hands back tokens.
 *
 * The device grant is requested before the server starts so the page always
 * renders a valid code, and a failed grant closes the server again instead of
 * leaving a dead page open.
 */
export declare function startOnboarding(config: OAuthConfig, options?: OnboardingOptions): Promise<OnboardingHandle>;
/**
 * Guide-driven login: equivalent to `runDeviceLogin` but with the browser page
 * carrying the device code, for windows that have no visible terminal.
 */
export declare function runVisualDeviceLogin(config: OAuthConfig, options?: OnboardingOptions & {
    sink?: {
        write(text: string): void;
    };
}): Promise<StoredTokens>;
/** Windows users launch dsh from the desktop app, which may have no console. */
export declare function prefersVisualOnboarding(platform?: NodeJS.Platform): boolean;
export {};
