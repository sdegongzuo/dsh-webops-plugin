/**
 * Direct-fetch xAI/Grok adapter. Connection facts and the OAuth access token
 * resolve once per request, matching dsh-llm-deepseek so configuration and
 * token refresh reach the next call without a restart.
 */
import { LlmAdapter } from '@deepseek-ai/dsh-llm';
import type { GenerateOptions, LlmModelInfo, LlmProviderInfo, LlmResolvedModelInfo, ModelModality, ResolvedRetryPolicy, StreamChunk } from '@deepseek-ai/dsh-llm';
import type { AttachmentStore } from '@deepseek-ai/dsh-attachment';
import type { RequestDefaults, XaiReasoningEffort } from './serialize.js';
import type { WireError } from './types.js';
import { type LastPromptBudget } from './context-budget.js';
export interface XaiCatalogModel {
    id: string;
    name?: string;
    description?: string;
    contextWindow?: number;
    maxTokens?: number;
    inputModalities?: ModelModality[];
    reasoningEfforts?: XaiReasoningEffort[];
    defaultEffort?: XaiReasoningEffort;
}
export interface XaiConnectionOptions {
    baseURL: string;
    clientVersion: string;
    clientMode: string;
    defaults: RequestDefaults;
    maxTokens: number;
    defaultContextWindow: number;
    models: readonly XaiCatalogModel[];
    streamIdleTimeoutMs: number;
    retryPolicy: ResolvedRetryPolicy;
}
export interface XaiAdapterOptions {
    options: () => XaiConnectionOptions;
    resolveAccessToken: (connection: XaiConnectionOptions) => Promise<string>;
    /** Called after HTTP 401/403 so the next attempt can use a fresh token. */
    refreshAccessToken?: (connection: XaiConnectionOptions) => Promise<string>;
    resolveAttachments?: () => AttachmentStore | undefined;
    /** Live SuperGrok catalog; when present it outranks the static fallback. */
    liveCatalog?: () => readonly XaiCatalogModel[] | undefined;
}
export declare const DEFAULT_STREAM_IDLE_TIMEOUT_MS = 300000;
export declare const DEFAULT_CONTEXT_WINDOW = 500000;
export declare const DEFAULT_MAX_TOKENS = 64000;
/** Leave a tiny remainder so compaction, not a 1-token completion, owns a full window. */
export declare const MIN_COMPLETION_TOKENS = 16;
/** Parse one SuperGrok / OpenAI-compatible model listing into a catalog entry. */
export declare function catalogModelFromListing(value: unknown): XaiCatalogModel | undefined;
/** Merge a live `/models` listing over the static fallback catalog. */
export declare function mergeXaiCatalog(fallback: readonly XaiCatalogModel[], listed: readonly XaiCatalogModel[]): XaiCatalogModel[];
/**
 * Failure codes this route can raise. Every member is built into dsh-llm, but
 * the narrower `BuiltinLlmFailureCode` export only exists from 0.2.2 on, so the
 * union is declared here to keep the source compiling on 0.2.1 hosts too.
 */
type XaiFailureCode = 'AUTH' | 'QUOTA' | 'RATE_LIMIT' | 'CONTEXT_WINDOW_EXCEEDED' | 'INVALID_REQUEST' | 'SERVER' | `HTTP_${number}`;
export declare function httpErrorCode(status: number, error?: WireError['error']): XaiFailureCode;
export declare class XaiAdapter extends LlmAdapter {
    private readonly config;
    constructor(config: XaiAdapterOptions);
    /**
     * This route prices images as inline bytes, not as provider visual tokens,
     * so measurement falls back to the harness text estimate. Declared outright:
     * 0.1.5 and 0.1.7 both call it while metering a request.
     */
    imageRequestPricing(_provider: string, _model: string): undefined;
    private readonly lastPrompt;
    /** Test / recovery hook: seed the last successful prompt sample for a session. */
    rememberPrompt(sessionId: string, budget: LastPromptBudget): void;
    providerInfo(provider: string): LlmProviderInfo;
    providerRetryPolicy(_provider: string): ResolvedRetryPolicy;
    private catalog;
    listModels(provider: string): Promise<readonly LlmModelInfo[]>;
    resolveModel(provider: string, model: string, _signal?: AbortSignal): Promise<LlmResolvedModelInfo>;
    private assertFitsContext;
    private planBudget;
    stream(options: GenerateOptions): AsyncIterable<StreamChunk>;
    private resolveImages;
    private request;
}
export {};
