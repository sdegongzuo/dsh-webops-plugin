import type { OAuthConfig, StoredTokens, TokenSource } from './tokens.js';
export type TokenSourceKind = TokenSource;
export interface DiscoveredTokens extends StoredTokens {
    path: string;
}
export declare function explicitSearchPaths(home?: string, config?: OAuthConfig): string[];
export declare function discoveryRoots(home?: string): string[];
export declare function searchLocalTokens(config?: OAuthConfig, home?: string): Promise<DiscoveredTokens | null>;
export declare function expiresInSeconds(tokens: StoredTokens): number | undefined;
