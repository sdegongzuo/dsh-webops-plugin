import type { Context } from '@deepseek-ai/cordis';
export declare const DEFAULT_DSH_PROVIDER = "xai";
export declare const DEFAULT_DSH_MODEL = "grok-4.7";
export declare const DEFAULT_DSH_REASONING_EFFORT = "high";
export interface DshDefaultModel {
    provider: string;
    model: string;
    reasoningEffort?: string;
}
export declare function dshHomeDir(): string;
export declare function dshSettingsPath(home?: string): string;
export declare function defaultModelSelection(): DshDefaultModel;
export declare function upsertDefaultModelSection(document: string, selection: DshDefaultModel): string;
/** True when the settings file already carries any `agent-default-model` section. */
export declare function settingsHasAnyDefaultModel(document: string): boolean;
export declare function settingsHasDefaultModel(document: string, selection: DshDefaultModel): boolean;
export declare function writeDshDefaultModelFile(selection?: DshDefaultModel, path?: string): Promise<string>;
export declare function applyDshDefaultModel(ctx: Context | undefined, selection?: DshDefaultModel, options?: {
    onlyIfUnset?: boolean;
}): Promise<'service' | 'file' | 'unchanged'>;
