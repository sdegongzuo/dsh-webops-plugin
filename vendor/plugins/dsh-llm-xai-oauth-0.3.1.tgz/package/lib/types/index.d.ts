/**
 * Register an `xai` LLM route that authenticates with SuperGrok / X Premium
 * OAuth tokens. On start the plugin searches the machine for a reusable
 * grok-bridge / Grok CLI token, falls back to the xAI device-code login on a
 * TTY, then writes `agent-default-model` so `/model` and new agents land on
 * Grok. Connection facts resolve per request from this plugin's volatile
 * Config in the profile patch; the access token is refreshed from
 * ~/.grok-bridge/auth.json just before each call.
 *
 * @module dsh-llm-xai-oauth
 */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import type { RetryPolicyConfig } from '@deepseek-ai/dsh-llm';
import type { XaiCatalogModel, XaiConnectionOptions } from './adapter.js';
import type { XaiReasoningEffort } from './serialize.js';
export { XaiAdapter, catalogModelFromListing, mergeXaiCatalog } from './adapter.js';
export type { XaiAdapterOptions, XaiCatalogModel, XaiConnectionOptions } from './adapter.js';
export { estimateRequestTokens, projectPromptTokens, projectedPromptTokens, promptTokensFromUsage, planRequestBudget, shouldTriggerCompaction, } from './context-budget.js';
export { httpErrorCode } from './adapter.js';
export { DEFAULT_AUTH_BASE, DEFAULT_CLIENT_ID, DEFAULT_SCOPE, DEFAULT_UPSTREAM_BASE, getAccessToken, refreshAccessTokenAfterUnauthorized, refreshStoredTokens, tokenNeedsRefresh, loadCanonicalTokens, loadStoredTokens, } from './oauth.js';
export { main as cliMain, runRefreshDaemon } from './cli.js';
export { bootstrapXaiOAuth } from './bootstrap.js';
export { renderOnboardingPage, runVisualDeviceLogin, startOnboarding } from './onboarding.js';
export type { OnboardingHandle, OnboardingOptions } from './onboarding.js';
export { searchLocalTokens } from './discover.js';
export { applyDshDefaultModel, defaultModelSelection } from './dsh-defaults.js';
export declare const name = "llm-xai-oauth";
export declare const inject: string[];
export interface Config {
    /** Subscription proxy used with OAuth (default cli-chat-proxy.grok.com/v1). */
    baseURL?: string;
    /** Metered API fallback, unused while OAuth tokens exist. */
    apiBaseURL?: string;
    clientVersion?: string;
    clientMode?: string;
    reasoningEffort?: XaiReasoningEffort;
    maxTokens?: number;
    defaultContextWindow?: number;
    models?: XaiCatalogModel[];
    streamIdleTimeoutMs?: number;
    retryPolicy?: RetryPolicyConfig;
}
export declare const Config: z;
/**
 * Read one config snapshot.
 *
 * A volatile field (0.1.7) contributes its current snapshot, including an
 * absent one, which is what lets a settings edit reach the next request. A
 * plain field contributes only a value that is actually present, so a 0.1.5
 * section entry does not restate every schema default as if the user set it.
 */
export declare function plainConfig(config: Config): Config;
export declare function resolveAdapterOptions(config: Config): XaiConnectionOptions;
export declare function apply(ctx: Context, config: Config): Promise<void>;
declare const _default: {
    name: string;
    inject: string[];
    Config: z;
    apply: typeof apply;
};
export default _default;
