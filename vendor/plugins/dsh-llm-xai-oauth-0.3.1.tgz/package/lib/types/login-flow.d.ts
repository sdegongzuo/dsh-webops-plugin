import type { DeviceCode, OAuthConfig, StoredTokens } from './oauth.js';
export interface LoginSink {
    write(text: string): void;
}
export interface LoginOptions {
    sink?: LoginSink;
    open?: (url: string) => boolean | Promise<boolean>;
    signal?: AbortSignal;
}
export declare function formatLoginPrompt(device: DeviceCode): string;
export declare function runDeviceLogin(config: OAuthConfig, options?: LoginOptions): Promise<StoredTokens>;
export declare function canPromptLogin(): boolean;
/**
 * Pick the login surface for this host.
 *
 * Windows is served by the visual guide because the desktop client does not
 * attach a console: the terminal-only flow would never print its code. Every
 * other host keeps the terminal flow, and a host that cannot open a browser
 * at all still needs one — the guide renders the URL on stderr.
 */
export declare function loginPrefersVisual(options?: {
    visual?: boolean;
    platform?: NodeJS.Platform;
}): boolean;
export declare function loginDisabledByEnv(): boolean;
