/**
 * Whether this host may launch a browser at all. Set GROK_BRIDGE_NO_BROWSER=1
 * on SSH / CI / headless hosts so the login prints its URL instead.
 */
export declare function browserAllowed(): boolean;
/**
 * Best-effort open of the device-login page. Disabled with
 * GROK_BRIDGE_NO_BROWSER=1 so SSH / CI / headless hosts print the URL instead.
 */
export declare function openBrowser(url: string): Promise<boolean>;
