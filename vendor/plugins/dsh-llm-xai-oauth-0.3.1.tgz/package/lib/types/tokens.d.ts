export interface OAuthConfig {
    authBase: string;
    tokenPath: string;
    deviceCodePath: string;
    clientId: string;
    scope: string;
    authFile: string;
    grokCliAuthFile: string;
    configFile: string;
}
export type TokenSource = 'grok-bridge' | 'grok-cli' | 'discovered';
export interface StoredTokens {
    accessToken: string;
    refreshToken: string | null;
    expiresAt: number | null;
    clientId: string | null;
    source: TokenSource;
}
export declare function normalizeTokens(raw: unknown, source: TokenSource): StoredTokens | null;
