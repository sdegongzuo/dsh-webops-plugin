import type { TerminalBottomProps } from './TerminalView.tsx';
/** The terminal view, deferred until its tab is first mounted. */
export declare const LazyTerminalBottom: (props: TerminalBottomProps) => import("react").ReactNode;
