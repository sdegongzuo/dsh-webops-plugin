import type { SidebarSettingsRenderProps } from '../service.ts';
/** The plugin-owned setting key (mirrored host-side in src/index.ts). */
export declare const COMMIT_MODEL_SETTING_KEY = "commitModel";
export declare function CommitModelSettings(props: SidebarSettingsRenderProps): import("react").JSX.Element;
